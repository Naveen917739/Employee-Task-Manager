
from flask import Flask, request, jsonify
import sqlite3
from contextlib import closing

app = Flask(__name__)
DATABASE = "tasks.db"

def init_db():
    with closing(sqlite3.connect(DATABASE)) as conn:
        conn.execute(
            '''CREATE TABLE IF NOT EXISTS tasks (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   title TEXT NOT NULL,
                   status TEXT NOT NULL
               )'''
        )
        conn.commit()

def row_to_dict(row):
    return {"id": row[0], "title": row[1], "status": row[2]}

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200

@app.route("/tasks", methods=["GET"])
def get_tasks():
    with closing(sqlite3.connect(DATABASE)) as conn:
        cur = conn.execute("SELECT id, title, status FROM tasks ORDER BY id")
        rows = cur.fetchall()
    return jsonify([row_to_dict(r) for r in rows]), 200

@app.route("/tasks", methods=["POST"])
def add_task():
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400
    data = request.get_json(silent=True) or {}
    title = data.get("title")
    status = data.get("status", "Pending")
    if not title:
        return jsonify({"error": "Field 'title' is required"}), 400

    with closing(sqlite3.connect(DATABASE)) as conn:
        cur = conn.execute("INSERT INTO tasks (title, status) VALUES (?, ?)", (title, status))
        conn.commit()
        new_id = cur.lastrowid
    return jsonify({"message": "Task added", "id": new_id}), 201

@app.route("/tasks/<int:task_id>", methods=["PUT"])
def update_task(task_id):
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400
    data = request.get_json(silent=True) or {}
    status = data.get("status")
    if status is None:
        return jsonify({"error": "Field 'status' is required"}), 400

    with closing(sqlite3.connect(DATABASE)) as conn:
        cur = conn.execute("UPDATE tasks SET status=? WHERE id=?", (status, task_id))
        conn.commit()
        if cur.rowcount == 0:
            return jsonify({"error": f"Task {task_id} not found"}), 404
    return jsonify({"message": "Task updated"}), 200

@app.route("/tasks/<int:task_id>", methods=["DELETE"])
def delete_task(task_id):
    with closing(sqlite3.connect(DATABASE)) as conn:
        cur = conn.execute("DELETE FROM tasks WHERE id=?", (task_id,))
        conn.commit()
        if cur.rowcount == 0:
            return jsonify({"error": f"Task {task_id} not found"}), 404
    return jsonify({"message": "Task deleted"}), 200

if __name__ == "__main__":
    init_db()
    print("Database initialized -> tasks.db")
    app.run(debug=True)
