
# Employee Task Management System (Flask + SQLite)

A minimal REST API to manage employee tasks. Perfect for GitHub portfolio and quick testing.

## Endpoints
- `GET /health` → quick health check
- `GET /tasks` → list tasks
- `POST /tasks` → create task `{ "title": "Finish report", "status": "Pending" }`
- `PUT /tasks/{id}` → update status `{ "status": "Completed" }`
- `DELETE /tasks/{id}` → delete task

## Quick Start (Windows / macOS / Linux)
1) Ensure Python 3.9+ is installed.
2) Install dependencies:
```bash
pip install -r requirements.txt
```
3) Run the API:
```bash
python app.py
```
4) Open your browser: http://127.0.0.1:5000/health

## Test with curl
See `tests/curl_test.sh` (Linux/macOS) or `tests/curl_test.bat` (Windows) for ready-made commands.

## Postman
Import `tests/EmployeeTaskManager.postman_collection.json` into Postman and use the saved requests.

## Notes
- The SQLite database file `tasks.db` is created automatically on first run.
- This starter is intentionally simple for learning/demo purposes.
