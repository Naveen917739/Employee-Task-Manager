
# Step-by-Step: Run & Test the Employee Task Manager

## 1) Create a folder and files
- Put `app.py`, `requirements.txt`, and this guide in the same folder.

## 2) Install dependencies
```bash
pip install -r requirements.txt
```

## 3) Run the server
```bash
python app.py
```
Expected output includes:
```
Database initialized -> tasks.db
 * Running on http://127.0.0.1:5000
```

## 4) Test in your browser
Open: `http://127.0.0.1:5000/health` → should show `{"status":"ok"}`

## 5) Test with curl (Linux/macOS)
```bash
curl http://127.0.0.1:5000/tasks
curl -X POST http://127.0.0.1:5000/tasks -H "Content-Type: application/json" -d "{"title":"Finish Python project","status":"Pending"}"
curl http://127.0.0.1:5000/tasks
curl -X PUT http://127.0.0.1:5000/tasks/1 -H "Content-Type: application/json" -d "{"status":"Completed"}"
curl -X DELETE http://127.0.0.1:5000/tasks/1
```

## 6) Test on Windows (PowerShell / CMD)
Use `tests\curl_test.bat` or run these commands:
```bat
curl http://127.0.0.1:5000/tasks
curl -X POST http://127.0.0.1:5000/tasks -H "Content-Type: application/json" -d "{"title":"Finish Python project","status":"Pending"}"
curl http://127.0.0.1:5000/tasks
curl -X PUT http://127.0.0.1:5000/tasks/1 -H "Content-Type: application/json" -d "{"status":"Completed"}"
curl -X DELETE http://127.0.0.1:5000/tasks/1
```

## 7) Postman (optional)
- Open Postman → Import → choose `tests/EmployeeTaskManager.postman_collection.json`
- Use the saved `GET /tasks`, `POST /tasks`, `PUT /tasks/{id}`, and `DELETE /tasks/{id}` requests.
