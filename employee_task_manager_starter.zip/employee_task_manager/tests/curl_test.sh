
#!/usr/bin/env bash
set -e

echo "=== GET tasks ==="
curl http://127.0.0.1:5000/tasks
echo

echo "=== ADD task ==="
curl -X POST http://127.0.0.1:5000/tasks -H "Content-Type: application/json" -d '{"title":"Finish Python project","status":"Pending"}'
echo

echo "=== GET tasks (after add) ==="
curl http://127.0.0.1:5000/tasks
echo

echo "=== UPDATE task id 1 ==="
curl -X PUT http://127.0.0.1:5000/tasks/1 -H "Content-Type: application/json" -d '{"status":"Completed"}'
echo

echo "=== DELETE task id 1 ==="
curl -X DELETE http://127.0.0.1:5000/tasks/1
echo
